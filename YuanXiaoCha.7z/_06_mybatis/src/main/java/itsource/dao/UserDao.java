package itsource.dao;

import itsource.entity.User;

import java.util.List;

public interface UserDao {
    List<User> mybatis();
}
