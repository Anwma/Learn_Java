package itsource.service;

import itsource.entity.User;

import java.util.List;

public interface IUserService {
    List<User> mybatis();
}
